/* =========================================================
   MALAKOI — datos del catálogo
   Este es el ÚNICO archivo que tienes que editar para
   cambiar precios, medidas, materiales o agregar prendas.
   ========================================================= */

/* Número de WhatsApp en formato internacional, sin + ni espacios.
   Ejemplo Perú: 51 + número de 9 dígitos. */
const WHATSAPP = "51999999999";

const PRODUCTOS = {

    1: {
        nombre: "Morí denim Jacket",
        imagen: "img/producto1.jpeg",
        precio: 180,
        precioAnterior: 199,
        categoria: "Casaca",
        descripcion:
            "Casaca de denim de 10 onzas, 100% algodón. Tejido firme que se amolda con el uso y guarda las marcas de quien la usa.",
        ficha: {
            "Material": "Denim 10 onzas (100% algodón)",
            "Tallas": "S y L",
            "Cuidado": "Lavar a mano, agua fría, secar a la sombra"
        },
        notaTallas: "",
        tallas: {
            S: {
                "Largo": "61 cm",
                "Ancho": "62 cm",
                "Hombros": "24 cm",
                "Mangas": "50 cm"
            },
            L: {
                "Largo": "65 cm",
                "Ancho": "64 cm",
                "Hombros": "25.5 cm",
                "Mangas": "53 cm"
            }
        }
    },

    2: {
        nombre: "CAMISA LOTUS BOXY",
        imagen: "img/producto2.jpeg",
        precio: 125,
        precioAnterior: null,
        categoria: "Camisa",
        descripcion:
            "Camisa de denim de 5 onzas con corte boxy. Lleva botones chinos hechos de cordón elástico y, además, botones de camisa.",
        ficha: {
            "Material": "Denim 5 onzas",
            "Corte": "Boxy",
            "Botones": "Chinos de cordón elástico y botones de camisa",
            "Tallas": "Talla estándar (S)"
        },
        notaTallas: "Esta prenda sale en talla estándar.",
        tallas: {
            S: {
                "Largo": "61 cm",
                "Ancho": "60 cm",
                "Corte": "Boxy"
            }
        }
    },

    3: {
        nombre: "Parachute Jogger",
        imagen: "img/producto3.jpeg",
        precio: 95,
        precioAnterior: null,
        categoria: "Pantalón",
        descripcion:
            "Pantalón parachute jogger de caída amplia, con cintura elástica que se ajusta a varias medidas y basta recogida.",
        ficha: {
            "Corte": "Parachute jogger",
            "Cintura": "Elástica regulable",
            "Tallas": "S y L",
            "Cuidado": "Lavar a máquina en ciclo suave"
        },
        notaTallas: "",
        tallas: {
            S: {
                "Cintura": "65 cm hasta 92 cm",
                "Ancho de pierna": "37 cm",
                "Contorno de pierna": "74 cm",
                "Basta": "18 cm",
                "Largo": "107 cm"
            },
            L: {
                "Cintura": "67 cm hasta 95 cm",
                "Ancho de pierna": "37 cm",
                "Contorno de pierna": "74 cm",
                "Basta": "18 cm",
                "Largo": "107 cm"
            }
        }
    }

};
