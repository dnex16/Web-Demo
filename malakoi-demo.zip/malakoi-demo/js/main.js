/* =========================================================
   MALAKOI — comportamiento del sitio
   ========================================================= */

(function () {
    "use strict";

    /* ---------- Menú móvil ---------- */

    const botonMenu = document.querySelector(".menu-btn");
    const nav = document.getElementById("nav");

    if (botonMenu && nav) {

        botonMenu.addEventListener("click", function () {
            const abierto = botonMenu.getAttribute("aria-expanded") === "true";
            botonMenu.setAttribute("aria-expanded", String(!abierto));
            nav.setAttribute("data-abierto", String(!abierto));
        });

        nav.addEventListener("click", function (evento) {
            if (evento.target.tagName === "A") {
                botonMenu.setAttribute("aria-expanded", "false");
                nav.setAttribute("data-abierto", "false");
            }
        });

        document.addEventListener("keydown", function (evento) {
            if (evento.key === "Escape") {
                botonMenu.setAttribute("aria-expanded", "false");
                nav.setAttribute("data-abierto", "false");
            }
        });
    }


    /* ---------- Detalle de producto ---------- */

    const raiz = document.getElementById("detalle");

    if (!raiz || typeof PRODUCTOS === "undefined") {
        return;
    }

    const soles = new Intl.NumberFormat("es-PE", {
        style: "currency",
        currency: "PEN",
        minimumFractionDigits: 2
    });

    const id = new URLSearchParams(window.location.search).get("id");
    const producto = PRODUCTOS[id];

    /* Producto inexistente: se muestra una salida útil, no una página en blanco. */
    if (!producto) {
        raiz.className = "vacio";
        raiz.innerHTML =
            '<h1>No encontramos esa prenda</h1>' +
            '<p>Puede que el enlace esté incompleto o que la prenda ya no esté disponible.</p>' +
            '<a href="productos.html" class="btn">Ver el catálogo</a>';
        document.title = "Prenda no encontrada | Malakoi";
        return;
    }

    const tallas = Object.keys(producto.tallas);

    /* Textos y metadatos */
    document.title = producto.nombre + " | Malakoi";

    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
        meta.setAttribute("content", producto.descripcion);
    }

    const miga = document.getElementById("miga-actual");
    if (miga) {
        miga.textContent = producto.nombre;
    }

    const imagen = document.getElementById("imagenProducto");
    imagen.src = producto.imagen;
    imagen.alt = producto.nombre + " — Malakoi";

    document.getElementById("nombreProducto").textContent = producto.nombre;

    const precio = document.getElementById("precioProducto");
    precio.innerHTML =
        (producto.precioAnterior
            ? '<span class="precio-anterior">' + soles.format(producto.precioAnterior) + "</span>"
            : "") +
        "<span>" + soles.format(producto.precio) + "</span>";

    document.getElementById("descripcionProducto").textContent = producto.descripcion;

    /* Ficha técnica */
    const ficha = document.getElementById("fichaProducto");
    ficha.innerHTML = Object.entries(producto.ficha)
        .map(function (par) {
            return "<li><strong>" + par[0] + ":</strong> " + par[1] + "</li>";
        })
        .join("");

    /* Nota de tallas (por ejemplo, prendas de talla estándar) */
    const nota = document.getElementById("notaTallas");
    if (nota) {
        if (producto.notaTallas) {
            nota.textContent = producto.notaTallas;
        } else {
            nota.remove();
        }
    }

    /* Selector de tallas */
    const contenedorTallas = document.getElementById("tallas");
    const medidas = document.getElementById("medidas");
    const enlaceWsp = document.getElementById("whatsapp");

    let tallaActiva = tallas[0];

    contenedorTallas.innerHTML = tallas
        .map(function (talla) {
            return (
                '<button type="button" class="talla" data-talla="' + talla + '" ' +
                'aria-pressed="' + (talla === tallaActiva) + '">' + talla + "</button>"
            );
        })
        .join("");

    contenedorTallas.addEventListener("click", function (evento) {
        const boton = evento.target.closest(".talla");
        if (!boton) {
            return;
        }
        tallaActiva = boton.dataset.talla;
        actualizar();
    });

    function actualizar() {

        contenedorTallas.querySelectorAll(".talla").forEach(function (boton) {
            boton.setAttribute("aria-pressed", String(boton.dataset.talla === tallaActiva));
        });

        medidas.innerHTML = Object.entries(producto.tallas[tallaActiva])
            .map(function (par) {
                return (
                    '<div class="medida"><dt>' + par[0] + "</dt><dd>" + par[1] + "</dd></div>"
                );
            })
            .join("");

        const mensaje =
            "Hola Malakoi, me interesa la prenda " + producto.nombre +
            " en talla " + tallaActiva + " (" + soles.format(producto.precio) + "). " +
            "¿Sigue disponible?";

        enlaceWsp.href =
            "https://wa.me/" + WHATSAPP + "?text=" + encodeURIComponent(mensaje);
    }

    actualizar();

    /* Datos estructurados para Google (se arman con el producto ya cargado) */
    const datos = {
        "@context": "https://schema.org",
        "@type": "Product",
        "name": producto.nombre,
        "image": producto.imagen,
        "description": producto.descripcion,
        "brand": { "@type": "Brand", "name": "Malakoi" },
        "offers": {
            "@type": "Offer",
            "priceCurrency": "PEN",
            "price": producto.precio,
            "availability": "https://schema.org/InStock"
        }
    };

    const script = document.createElement("script");
    script.type = "application/ld+json";
    script.textContent = JSON.stringify(datos);
    document.head.appendChild(script);

})();
