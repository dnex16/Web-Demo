/* =========================================================
   MALAKOI — checkout.html
   Arma el resumen del pedido a partir del carrito, valida el
   formulario y guarda el pedido en localStorage para mostrarlo
   en confirmacion.html. No hay pasarela de pago conectada:
   Yape/Plin y transferencia se validan de forma manual (el
   cliente envía su comprobante) y contra entrega se cobra en
   efectivo al recibir. Reemplaza DATOS_YAPE / DATOS_BANCO más
   abajo por tus datos reales antes de publicar el sitio.
   ========================================================= */

(function () {
    "use strict";

    const form = document.getElementById("formCheckout");
    if (!form || typeof PRODUCTOS === "undefined") {
        return;
    }

    const soles = new Intl.NumberFormat("es-PE", {
        style: "currency",
        currency: "PEN",
        minimumFractionDigits: 2
    });

    const vacio = document.getElementById("checkoutVacio");
    const resumenLista = document.getElementById("resumenLista");
    const resumenSubtotal = document.getElementById("resumenSubtotal");
    const resumenTotal = document.getElementById("resumenTotal");

    function mostrarToast(texto) {
        const toast = document.getElementById("toast");
        if (!toast) {
            return;
        }
        toast.textContent = texto;
        toast.classList.add("visible");
        clearTimeout(toast._temporizador);
        toast._temporizador = setTimeout(function () {
            toast.classList.remove("visible");
        }, 2600);
    }

    function itemsValidos() {
        return Carrito.leer().filter(function (it) {
            return !!PRODUCTOS[it.id];
        });
    }

    function renderResumen() {
        const items = itemsValidos();

        if (items.length === 0) {
            form.hidden = true;
            vacio.hidden = false;
            return;
        }

        form.hidden = false;
        vacio.hidden = true;

        let total = 0;

        resumenLista.innerHTML = items.map(function (it, indice) {
            const producto = PRODUCTOS[it.id];
            const subtotal = producto.precio * it.cantidad;
            total += subtotal;
            const disponible = Carrito.stockDisponible(it.id, it.talla);
            const enElTope = it.cantidad >= disponible;

            return (
                '<div class="carrito-item">' +
                '<img src="' + producto.imagen + '" alt="' + producto.nombre + '">' +
                '<div class="carrito-item-info">' +
                "<h3>" + producto.nombre + "</h3>" +
                '<p class="carrito-item-talla">Talla ' + it.talla + "</p>" +
                '<div class="carrito-cantidad">' +
                '<button type="button" class="carrito-qty" data-idx="' + indice + '" data-delta="-1" aria-label="Restar una unidad">−</button>' +
                "<span>" + it.cantidad + "</span>" +
                '<button type="button" class="carrito-qty" data-idx="' + indice + '" data-delta="1" aria-label="Sumar una unidad"' + (enElTope ? " disabled" : "") + ">+</button>" +
                "</div>" +
                "</div>" +
                '<div class="carrito-item-precio">' +
                "<span>" + soles.format(subtotal) + "</span>" +
                '<button type="button" class="carrito-eliminar" data-idx="' + indice + '">Quitar</button>' +
                "</div>" +
                "</div>"
            );
        }).join("");

        resumenSubtotal.textContent = soles.format(total);
        resumenTotal.textContent = soles.format(total);
    }

    resumenLista.addEventListener("click", function (evento) {
        const botonQty = evento.target.closest(".carrito-qty");
        const botonEliminar = evento.target.closest(".carrito-eliminar");

        if (botonQty) {
            const indice = Number(botonQty.dataset.idx);
            const delta = Number(botonQty.dataset.delta);
            const items = Carrito.leer();
            if (items[indice]) {
                const disponible = Carrito.stockDisponible(items[indice].id, items[indice].talla);
                if (delta > 0 && items[indice].cantidad >= disponible) {
                    mostrarToast("No queda más stock de esta talla");
                } else {
                    Carrito.actualizarCantidad(indice, items[indice].cantidad + delta);
                }
            }
            renderResumen();
        }

        if (botonEliminar) {
            Carrito.eliminar(Number(botonEliminar.dataset.idx));
            renderResumen();
        }
    });

    renderResumen();

    /* Enlace de consulta (no de compra): mantiene el número de
       WhatsApp solo como canal de soporte, como pidió el negocio. */
    const enlaceWsp = document.getElementById("checkoutWhatsapp");
    if (enlaceWsp && typeof WHATSAPP !== "undefined") {
        enlaceWsp.href = "https://wa.me/" + WHATSAPP +
            "?text=" + encodeURIComponent("Hola Malakoi, tengo una consulta sobre mi pedido antes de pagar.");
    }


    /* ---------- Validación del formulario ---------- */

    function marcarError(idCampo, hayError) {
        const mensaje = form.querySelector('[data-error-para="' + idCampo + '"]');
        const campo = document.getElementById(idCampo);
        if (mensaje) {
            mensaje.hidden = !hayError;
        }
        if (campo) {
            campo.setAttribute("aria-invalid", String(hayError));
        }
    }

    function validar() {
        let valido = true;
        let primerError = null;

        ["cNombre", "cTelefono", "cRegion", "cDistrito", "cDireccion"].forEach(function (idCampo) {
            const campo = document.getElementById(idCampo);
            const hayError = !campo.value.trim();
            marcarError(idCampo, hayError);
            if (hayError) {
                valido = false;
                primerError = primerError || campo;
            }
        });

        const metodoElegido = form.querySelector('input[name="metodoPago"]:checked');
        const mensajeMetodo = form.querySelector('[data-error-para="metodosPago"]');
        if (!metodoElegido) {
            valido = false;
            if (mensajeMetodo) {
                mensajeMetodo.hidden = false;
            }
            primerError = primerError || document.getElementById("metodosPago");
        } else if (mensajeMetodo) {
            mensajeMetodo.hidden = true;
        }

        if (!valido && primerError) {
            primerError.scrollIntoView({ behavior: "smooth", block: "center" });
        }

        return valido;
    }


    /* ---------- Envío del pedido ---------- */

    const NOMBRES_METODO = {
        yape: "Yape / Plin",
        transferencia: "Transferencia bancaria",
        contraentrega: "Pago contra entrega"
    };

    form.addEventListener("submit", function (evento) {
        evento.preventDefault();

        if (!validar()) {
            mostrarToast("Revisa los campos marcados en rojo");
            return;
        }

        const items = itemsValidos();
        if (items.length === 0) {
            renderResumen();
            return;
        }

        let total = 0;
        const itemsPedido = items.map(function (it) {
            const producto = PRODUCTOS[it.id];
            const subtotal = producto.precio * it.cantidad;
            total += subtotal;
            return {
                nombre: producto.nombre,
                talla: it.talla,
                cantidad: it.cantidad,
                precioUnitario: producto.precio,
                subtotal: subtotal
            };
        });

        const metodoPago = form.querySelector('input[name="metodoPago"]:checked').value;

        const pedido = {
            id: "MK-" + Date.now().toString().slice(-8),
            fecha: new Date().toISOString(),
            cliente: {
                nombre: document.getElementById("cNombre").value.trim(),
                telefono: document.getElementById("cTelefono").value.trim(),
                correo: document.getElementById("cCorreo").value.trim(),
                region: document.getElementById("cRegion").value,
                distrito: document.getElementById("cDistrito").value.trim(),
                direccion: document.getElementById("cDireccion").value.trim(),
                referencia: document.getElementById("cReferencia").value.trim()
            },
            items: itemsPedido,
            total: total,
            metodoPago: metodoPago,
            metodoPagoNombre: NOMBRES_METODO[metodoPago] || metodoPago,
            estado: "Pendiente de confirmación de pago"
        };

        try {
            localStorage.setItem("malakoi_ultimo_pedido", JSON.stringify(pedido));
        } catch (e) {
            /* Si localStorage no está disponible, igual seguimos a la
               confirmación; el pedido solo no quedará guardado. */
        }

        Carrito.vaciar();
        window.location.href = "confirmacion.html";
    });

})();
