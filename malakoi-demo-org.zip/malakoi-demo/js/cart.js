/* =========================================================
   MALAKOI — carrito de compras
   Guarda el carrito en localStorage (solo en el navegador de
   cada visitante). El cierre de compra ya no depende de
   WhatsApp: el botón "Ir a pagar" lleva a checkout.html,
   que arma el pedido dentro de la propia página.
   Depende de que js/productos.js esté cargado antes.
   ========================================================= */

const Carrito = (function () {
    "use strict";

    const CLAVE = "malakoi_carrito";

    function leer() {
        try {
            const datos = JSON.parse(localStorage.getItem(CLAVE));
            return Array.isArray(datos) ? datos : [];
        } catch (e) {
            return [];
        }
    }

    function guardar(items) {
        try {
            localStorage.setItem(CLAVE, JSON.stringify(items));
        } catch (e) {
            /* localStorage no disponible: el carrito solo dura la sesión */
        }
        actualizarContador();
    }

    /* Límite real de unidades que se pueden pedir de una talla,
       según el stock declarado en productos.js. */
    function stockDisponible(id, talla) {
        const producto = PRODUCTOS[id];
        if (!producto || !producto.tallas[talla]) {
            return 0;
        }
        const info = producto.tallas[talla];
        return info.estado === "agotado" ? 0 : info.stock;
    }

    function agregar(id, talla, cantidad) {
        cantidad = Number(cantidad) || 1;

        const disponible = stockDisponible(id, talla);
        if (disponible <= 0) {
            return { ok: false, motivo: "agotado" };
        }

        const items = leer();
        const existente = items.find(function (it) {
            return it.id === id && it.talla === talla;
        });

        const yaEnCarrito = existente ? existente.cantidad : 0;
        const totalPedido = Math.min(yaEnCarrito + cantidad, disponible);
        const limitado = totalPedido < yaEnCarrito + cantidad;

        if (existente) {
            existente.cantidad = totalPedido;
        } else {
            items.push({ id: id, talla: talla, cantidad: totalPedido });
        }

        guardar(items);
        return { ok: true, limitado: limitado, cantidadFinal: totalPedido };
    }

    function actualizarCantidad(indice, cantidad) {
        const items = leer();
        if (!items[indice]) {
            return;
        }
        const disponible = stockDisponible(items[indice].id, items[indice].talla);
        if (cantidad <= 0) {
            items.splice(indice, 1);
        } else {
            items[indice].cantidad = Math.min(cantidad, disponible || cantidad);
        }
        guardar(items);
    }

    function eliminar(indice) {
        const items = leer();
        items.splice(indice, 1);
        guardar(items);
    }

    function vaciar() {
        guardar([]);
    }

    function contarItems() {
        return leer().reduce(function (suma, it) {
            return suma + it.cantidad;
        }, 0);
    }

    function actualizarContador() {
        const el = document.getElementById("carritoContador");
        if (!el) {
            return;
        }
        const n = contarItems();
        el.textContent = String(n);
        el.hidden = n === 0;
    }

    return {
        leer: leer,
        agregar: agregar,
        actualizarCantidad: actualizarCantidad,
        eliminar: eliminar,
        vaciar: vaciar,
        contarItems: contarItems,
        actualizarContador: actualizarContador,
        stockDisponible: stockDisponible
    };

})();


(function () {
    "use strict";

    if (typeof PRODUCTOS === "undefined") {
        return;
    }

    const soles = new Intl.NumberFormat("es-PE", {
        style: "currency",
        currency: "PEN",
        minimumFractionDigits: 2
    });

    function mostrarToast(texto) {
        const toast = document.getElementById("toast");
        if (!toast) {
            return;
        }
        toast.textContent = texto;
        toast.classList.add("visible");
        clearTimeout(toast._temporizador);
        toast._temporizador = setTimeout(function () {
            toast.classList.remove("visible");
        }, 2600);
    }

    function renderCarrito() {
        const lista = document.getElementById("carritoLista");
        const pie = document.getElementById("carritoPie");
        const totalEl = document.getElementById("carritoTotal");

        if (!lista) {
            return;
        }

        const items = Carrito.leer().filter(function (it) {
            return !!PRODUCTOS[it.id];
        });

        if (items.length === 0) {
            lista.innerHTML =
                '<div class="carrito-vacio">' +
                "<p>Tu carrito está vacío.</p>" +
                '<a href="productos.html" class="btn btn-linea">Ver catálogo</a>' +
                "</div>";
            if (pie) {
                pie.hidden = true;
            }
            return;
        }

        if (pie) {
            pie.hidden = false;
        }

        let total = 0;

        lista.innerHTML = items
            .map(function (it, indice) {
                const producto = PRODUCTOS[it.id];
                const subtotal = producto.precio * it.cantidad;
                total += subtotal;
                const disponible = Carrito.stockDisponible(it.id, it.talla);
                const enElTope = it.cantidad >= disponible;

                return (
                    '<div class="carrito-item">' +
                    '<img src="' + producto.imagen + '" alt="' + producto.nombre + '">' +
                    '<div class="carrito-item-info">' +
                    "<h3>" + producto.nombre + "</h3>" +
                    '<p class="carrito-item-talla">Talla ' + it.talla + "</p>" +
                    '<div class="carrito-cantidad">' +
                    '<button type="button" class="carrito-qty" data-idx="' + indice + '" data-delta="-1" aria-label="Restar una unidad">−</button>' +
                    "<span>" + it.cantidad + "</span>" +
                    '<button type="button" class="carrito-qty" data-idx="' + indice + '" data-delta="1" aria-label="Sumar una unidad"' + (enElTope ? " disabled" : "") + ">+</button>" +
                    "</div>" +
                    "</div>" +
                    '<div class="carrito-item-precio">' +
                    "<span>" + soles.format(subtotal) + "</span>" +
                    '<button type="button" class="carrito-eliminar" data-idx="' + indice + '">Quitar</button>' +
                    "</div>" +
                    "</div>"
                );
            })
            .join("");

        if (totalEl) {
            totalEl.textContent = soles.format(total);
        }
    }

    function abrirCarrito() {
        const fondo = document.getElementById("carritoFondo");
        const panel = document.getElementById("carritoPanel");
        if (!fondo || !panel) {
            return;
        }
        renderCarrito();
        fondo.hidden = false;
        panel.classList.add("abierto");
        panel.setAttribute("aria-hidden", "false");
        document.body.style.overflow = "hidden";
    }

    function cerrarCarrito() {
        const fondo = document.getElementById("carritoFondo");
        const panel = document.getElementById("carritoPanel");
        if (!fondo || !panel) {
            return;
        }
        panel.classList.remove("abierto");
        panel.setAttribute("aria-hidden", "true");
        document.body.style.overflow = "";
        setTimeout(function () {
            fondo.hidden = true;
        }, 260);
    }

    document.addEventListener("DOMContentLoaded", function () {
        Carrito.actualizarContador();

        const botonAbrir = document.getElementById("carritoAbrir");
        const botonCerrar = document.getElementById("carritoCerrar");
        const fondo = document.getElementById("carritoFondo");
        const lista = document.getElementById("carritoLista");
        const botonVaciar = document.getElementById("carritoVaciar");

        if (botonAbrir) {
            botonAbrir.addEventListener("click", abrirCarrito);
        }
        if (botonCerrar) {
            botonCerrar.addEventListener("click", cerrarCarrito);
        }
        if (fondo) {
            fondo.addEventListener("click", cerrarCarrito);
        }
        if (botonVaciar) {
            botonVaciar.addEventListener("click", function () {
                Carrito.vaciar();
                renderCarrito();
            });
        }

        document.addEventListener("keydown", function (evento) {
            if (evento.key === "Escape") {
                cerrarCarrito();
            }
        });

        if (lista) {
            lista.addEventListener("click", function (evento) {
                const botonQty = evento.target.closest(".carrito-qty");
                const botonEliminar = evento.target.closest(".carrito-eliminar");

                if (botonQty) {
                    const indice = Number(botonQty.dataset.idx);
                    const delta = Number(botonQty.dataset.delta);
                    const items = Carrito.leer();
                    if (items[indice]) {
                        const disponible = Carrito.stockDisponible(items[indice].id, items[indice].talla);
                        if (delta > 0 && items[indice].cantidad >= disponible) {
                            mostrarToast("No queda más stock de esta talla");
                        } else {
                            Carrito.actualizarCantidad(indice, items[indice].cantidad + delta);
                        }
                    }
                    renderCarrito();
                }

                if (botonEliminar) {
                    Carrito.eliminar(Number(botonEliminar.dataset.idx));
                    renderCarrito();
                }
            });
        }

        /* Delegado: funciona con botones "Agregar al carrito" que ya
           existen en la página y con los que se generan después
           (por ejemplo, la grilla del catálogo). */
        document.addEventListener("click", function (evento) {
            const boton = evento.target.closest("[data-agregar-carrito]");
            if (!boton || boton.disabled) {
                return;
            }
            evento.preventDefault();

            const id = boton.dataset.id;
            const producto = PRODUCTOS[id];
            if (!producto) {
                return;
            }

            let talla = boton.dataset.talla || primeraTallaDisponible(producto);

            const botonTallaActiva = document.querySelector(".talla[aria-pressed='true']");
            if (botonTallaActiva && document.getElementById("botonAgregarCarrito") === boton) {
                talla = botonTallaActiva.dataset.talla;
            }

            let cantidad = 1;
            const inputCantidad = document.getElementById("cantidadProducto");
            if (inputCantidad && document.getElementById("botonAgregarCarrito") === boton) {
                cantidad = Number(inputCantidad.value) || 1;
            }

            const resultado = Carrito.agregar(id, talla, cantidad);

            if (!resultado.ok) {
                mostrarToast("Esa talla ya no tiene stock");
                return;
            }

            if (resultado.limitado) {
                mostrarToast("Solo quedaban " + resultado.cantidadFinal + " unidad(es) de " + producto.nombre + ", talla " + talla);
            } else {
                mostrarToast(producto.nombre + " (talla " + talla + ") agregado al carrito");
            }
        });
    });

})();
