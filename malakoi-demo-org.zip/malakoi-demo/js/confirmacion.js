/* =========================================================
   MALAKOI — confirmacion.html
   Lee el último pedido guardado por checkout.js y muestra los
   pasos siguientes según el método de pago elegido.
   ========================================================= */

(function () {
    "use strict";

    const soles = new Intl.NumberFormat("es-PE", {
        style: "currency",
        currency: "PEN",
        minimumFractionDigits: 2
    });

    const SIGUIENTES_PASOS = {
        yape: "Envíanos la captura de tu pago por Yape o Plin junto con tu número de pedido para que empecemos a preparar tu envío.",
        transferencia: "Envíanos el comprobante de tu transferencia junto con tu número de pedido para que empecemos a preparar tu envío.",
        contraentrega: "Nuestro equipo te llamará al número que dejaste para coordinar el día de entrega. Pagas en efectivo cuando recibas tu pedido."
    };

    let pedido = null;
    try {
        pedido = JSON.parse(localStorage.getItem("malakoi_ultimo_pedido"));
    } catch (e) {
        pedido = null;
    }

    const sinPedido = document.getElementById("sinPedido");
    const conPedido = document.getElementById("conPedido");

    if (!pedido || !pedido.id) {
        sinPedido.hidden = false;
        return;
    }

    conPedido.hidden = false;

    document.getElementById("pedidoId").textContent = pedido.id;

    const siguiente = document.getElementById("confirmacionSiguiente");
    siguiente.textContent = SIGUIENTES_PASOS[pedido.metodoPago] ||
        "Nos pondremos en contacto contigo para coordinar el pago y el envío.";

    const items = document.getElementById("confirmacionItems");
    items.innerHTML = pedido.items.map(function (it) {
        return (
            '<div class="confirmacion-item">' +
            "<span>" + it.cantidad + "× " + it.nombre + " (talla " + it.talla + ")</span>" +
            "<span>" + soles.format(it.subtotal) + "</span>" +
            "</div>"
        );
    }).join("");

    document.getElementById("confirmacionTotal").textContent = soles.format(pedido.total);

    const datos = document.getElementById("confirmacionDatos");
    const c = pedido.cliente;
    const filas = [
        ["Nombre", c.nombre],
        ["Celular", c.telefono],
        ["Dirección", c.direccion + (c.referencia ? " — " + c.referencia : "")],
        ["Distrito", c.distrito + ", " + c.region],
        ["Método de pago", pedido.metodoPagoNombre]
    ];
    datos.innerHTML = filas.map(function (par) {
        return "<div class=\"medida\"><dt>" + par[0] + "</dt><dd>" + par[1] + "</dd></div>";
    }).join("");

    const enlaceWsp = document.getElementById("confirmacionWhatsapp");
    if (enlaceWsp && typeof WHATSAPP !== "undefined") {
        enlaceWsp.href = "https://wa.me/" + WHATSAPP +
            "?text=" + encodeURIComponent("Hola Malakoi, escribo por mi pedido " + pedido.id + ".");
    }

})();
