/* =========================================================
   MALAKOI — datos del catálogo
   Este es el ÚNICO archivo que tienes que editar para
   cambiar precios, medidas, materiales, stock o agregar
   prendas nuevas.

   Estado de cada talla:
     "disponible"  -> se puede comprar sin restricción
     "ultimas"     -> quedan pocas unidades (se avisa en la web)
     "agotado"     -> no se puede agregar al carrito
   ========================================================= */

/* Número de WhatsApp en formato internacional, sin + ni espacios.
   Se usa solo para consultas puntuales (tallas, envíos), nunca
   para cerrar una compra: eso ocurre en checkout.html. */
const WHATSAPP = "51999999999";

const PRODUCTOS = {

    1: {
        nombre: "Morí denim Jacket",
        imagen: "img/producto1.jpeg",
        precio: 180,
        precioAnterior: 199,
        categoria: "Casaca",
        descripcion:
            "Casaca de denim de 10 onzas, 100% algodón. Tejido firme que se amolda con el uso y guarda las marcas de quien la usa.",
        ficha: {
            "Material": "Denim 10 onzas (100% algodón)",
            "Tallas": "S y L",
            "Cuidado": "Lavar a mano, agua fría, secar a la sombra"
        },
        notaTallas: "",
        tallas: {
            S: {
                estado: "ultimas",
                stock: 2,
                medidas: {
                    "Largo": "61 cm",
                    "Ancho": "62 cm",
                    "Hombros": "24 cm",
                    "Mangas": "50 cm"
                }
            },
            L: {
                estado: "disponible",
                stock: 6,
                medidas: {
                    "Largo": "65 cm",
                    "Ancho": "64 cm",
                    "Hombros": "25.5 cm",
                    "Mangas": "53 cm"
                }
            }
        }
    },

    2: {
        nombre: "CAMISA LOTUS BOXY",
        imagen: "img/producto2.jpeg",
        precio: 125,
        precioAnterior: null,
        categoria: "Camisa",
        descripcion:
            "Camisa de denim de 5 onzas con corte boxy. Lleva botones chinos hechos de cordón elástico y, además, botones de camisa.",
        ficha: {
            "Material": "Denim 5 onzas",
            "Corte": "Boxy",
            "Botones": "Chinos de cordón elástico y botones de camisa",
            "Tallas": "Talla estándar (S)"
        },
        notaTallas: "Esta prenda sale en talla estándar.",
        tallas: {
            S: {
                estado: "disponible",
                stock: 9,
                medidas: {
                    "Largo": "61 cm",
                    "Ancho": "60 cm",
                    "Corte": "Boxy"
                }
            }
        }
    },

    3: {
        nombre: "Parachute Jogger",
        imagen: "img/producto3.jpeg",
        precio: 95,
        precioAnterior: null,
        categoria: "Pantalón",
        descripcion:
            "Pantalón parachute jogger de caída amplia, con cintura elástica que se ajusta a varias medidas y basta recogida.",
        ficha: {
            "Corte": "Parachute jogger",
            "Cintura": "Elástica regulable",
            "Tallas": "S y L",
            "Cuidado": "Lavar a máquina en ciclo suave"
        },
        notaTallas: "",
        tallas: {
            S: {
                estado: "agotado",
                stock: 0,
                medidas: {
                    "Cintura": "65 cm hasta 92 cm",
                    "Ancho de pierna": "37 cm",
                    "Contorno de pierna": "74 cm",
                    "Basta": "18 cm",
                    "Largo": "107 cm"
                }
            },
            L: {
                estado: "disponible",
                stock: 4,
                medidas: {
                    "Cintura": "67 cm hasta 95 cm",
                    "Ancho de pierna": "37 cm",
                    "Contorno de pierna": "74 cm",
                    "Basta": "18 cm",
                    "Largo": "107 cm"
                }
            }
        }
    }

};


/* ---------------------------------------------------------
   Utilidades de stock, compartidas por catálogo, detalle y
   carrito, para que el estado de una talla se calcule
   siempre de la misma forma.
   --------------------------------------------------------- */

function tallasProducto(producto) {
    return Object.keys(producto.tallas);
}

function estadoProducto(producto) {
    const estados = Object.values(producto.tallas).map(function (t) { return t.estado; });
    if (estados.every(function (e) { return e === "agotado"; })) {
        return "agotado";
    }
    if (estados.some(function (e) { return e === "ultimas"; })) {
        return "ultimas";
    }
    return "disponible";
}

function primeraTallaDisponible(producto) {
    const tallas = tallasProducto(producto);
    const disponible = tallas.find(function (t) { return producto.tallas[t].estado !== "agotado"; });
    return disponible || tallas[0];
}


/* ---------------------------------------------------------
   Reseñas de clientes (contenido de ejemplo).
   Reemplaza estos textos y nombres por reseñas reales de tus
   compradores antes de publicar el sitio.
   --------------------------------------------------------- */

const RESEÑAS = [
    {
        nombre: "Fabrizio A.",
        ubicacion: "Comprador en Lima",
        calificacion: 5,
        texto: "Pedí la casaca en talla L guiándome solo por las medidas y me quedó exacta. Se nota la tela gruesa apenas la tocas."
    },
    {
        nombre: "Camila R.",
        ubicacion: "Comprador en Arequipa",
        calificacion: 5,
        texto: "El jogger llegó en tres días a provincia y viene mejor cosido que ropa que he pagado el doble en otro lado."
    },
    {
        nombre: "Diego M.",
        ubicacion: "Comprador en Lima",
        calificacion: 4,
        texto: "Buena camisa boxy, el corte es amplio de verdad así que si te gusta más ajustada pide una talla menos."
    }
];
