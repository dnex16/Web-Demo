/* =========================================================
   MALAKOI — catálogo (productos.html)
   Lee PRODUCTOS (js/productos.js) y arma la grilla con
   filtros por categoría y orden por precio. Así, agregar o
   quitar una prenda en productos.js se refleja solo, sin
   tocar el HTML.
   ========================================================= */

(function () {
    "use strict";

    const grid = document.getElementById("catalogoGrid");

    if (!grid || typeof PRODUCTOS === "undefined") {
        return;
    }

    const soles = new Intl.NumberFormat("es-PE", {
        style: "currency",
        currency: "PEN",
        minimumFractionDigits: 2
    });

    const filtros = document.getElementById("filtrosCategoria");
    const orden = document.getElementById("ordenarPor");

    let categoriaActiva = "Todos";

    function obtenerCategorias() {
        const vistas = [];
        Object.values(PRODUCTOS).forEach(function (p) {
            if (vistas.indexOf(p.categoria) === -1) {
                vistas.push(p.categoria);
            }
        });
        return vistas;
    }

    function renderFiltros() {
        if (!filtros) {
            return;
        }
        const categorias = ["Todos"].concat(obtenerCategorias());
        filtros.innerHTML = categorias
            .map(function (cat) {
                return (
                    '<button type="button" class="filtro-btn" data-cat="' + cat + '" ' +
                    'aria-pressed="' + (cat === categoriaActiva) + '">' + cat + "</button>"
                );
            })
            .join("");
    }

    function obtenerLista() {
        let entradas = Object.entries(PRODUCTOS);

        if (categoriaActiva !== "Todos") {
            entradas = entradas.filter(function (par) {
                return par[1].categoria === categoriaActiva;
            });
        }

        const criterio = orden ? orden.value : "destacados";

        if (criterio === "precio-asc") {
            entradas.sort(function (a, b) { return a[1].precio - b[1].precio; });
        } else if (criterio === "precio-desc") {
            entradas.sort(function (a, b) { return b[1].precio - a[1].precio; });
        }

        return entradas;
    }

    function renderGrid() {
        const entradas = obtenerLista();

        if (entradas.length === 0) {
            grid.innerHTML = '<p class="catalogo-sin-resultados">No hay prendas en esta categoría por ahora.</p>';
            return;
        }

        grid.innerHTML = entradas
            .map(function (par) {
                const id = par[0];
                const p = par[1];
                const tallas = tallasProducto(p).join(" / ");
                const estado = estadoProducto(p);
                const tallaInicial = primeraTallaDisponible(p);

                let etiqueta = "";
                if (estado === "agotado") {
                    etiqueta = '<span class="etiqueta etiqueta-agotado">Agotado</span>';
                } else if (p.precioAnterior) {
                    etiqueta = '<span class="etiqueta">Precio rebajado</span>';
                } else if (estado === "ultimas") {
                    etiqueta = '<span class="etiqueta etiqueta-ultimas">Últimas piezas</span>';
                }

                return (
                    '<article class="producto-card' + (estado === "agotado" ? " producto-card-agotado" : "") + '">' +
                    '<div class="producto-card-media">' +
                    '<img src="' + p.imagen + '" alt="' + p.nombre + '" width="600" height="800" loading="lazy">' +
                    etiqueta +
                    "</div>" +
                    '<div class="producto-card-info">' +
                    '<h3><a href="producto.html?id=' + id + '">' + p.nombre + "</a></h3>" +
                    '<p class="detalle">' + p.categoria + " · tallas " + tallas + "</p>" +
                    '<p class="precio">' +
                    (p.precioAnterior
                        ? '<span class="precio-anterior">' + soles.format(p.precioAnterior) + "</span>"
                        : "") +
                    "<span>" + soles.format(p.precio) + "</span>" +
                    "</p>" +
                    '<button type="button" class="btn-agregar" data-agregar-carrito data-id="' + id + '" data-talla="' + tallaInicial + '"' + (estado === "agotado" ? " disabled" : "") + ">" + (estado === "agotado" ? "Agotado" : "Agregar al carrito") + "</button>" +
                    "</div>" +
                    "</article>"
                );
            })
            .join("");
    }

    if (filtros) {
        renderFiltros();
        filtros.addEventListener("click", function (evento) {
            const boton = evento.target.closest(".filtro-btn");
            if (!boton) {
                return;
            }
            categoriaActiva = boton.dataset.cat;
            filtros.querySelectorAll(".filtro-btn").forEach(function (b) {
                b.setAttribute("aria-pressed", String(b === boton));
            });
            renderGrid();
        });
    }

    if (orden) {
        orden.addEventListener("change", renderGrid);
    }

    renderGrid();

})();
