/* =========================================================
   MALAKOI — comportamiento del sitio
   ========================================================= */

(function () {
    "use strict";

    /* ---------- Menú móvil ---------- */

    const botonMenu = document.querySelector(".menu-btn");
    const nav = document.getElementById("nav");

    if (botonMenu && nav) {

        botonMenu.addEventListener("click", function () {
            const abierto = botonMenu.getAttribute("aria-expanded") === "true";
            botonMenu.setAttribute("aria-expanded", String(!abierto));
            nav.setAttribute("data-abierto", String(!abierto));
        });

        nav.addEventListener("click", function (evento) {
            if (evento.target.tagName === "A") {
                botonMenu.setAttribute("aria-expanded", "false");
                nav.setAttribute("data-abierto", "false");
            }
        });

        document.addEventListener("keydown", function (evento) {
            if (evento.key === "Escape") {
                botonMenu.setAttribute("aria-expanded", "false");
                nav.setAttribute("data-abierto", "false");
            }
        });
    }


    /* ---------- Cabecera con sombra al hacer scroll ---------- */

    const header = document.querySelector(".header");
    if (header) {
        const marcarScroll = function () {
            header.classList.toggle("header-con-sombra", window.scrollY > 4);
        };
        marcarScroll();
        window.addEventListener("scroll", marcarScroll, { passive: true });
    }


    /* ---------- Reseñas (home) ---------- */

    const grillaReseñas = document.getElementById("reseñasGrid");
    if (grillaReseñas && typeof RESEÑAS !== "undefined") {
        grillaReseñas.innerHTML = RESEÑAS.map(function (r) {
            const estrellas = "★".repeat(r.calificacion) + "☆".repeat(5 - r.calificacion);
            return (
                '<figure class="reseña-card">' +
                '<div class="reseña-estrellas" aria-hidden="true">' + estrellas + "</div>" +
                "<blockquote>" + r.texto + "</blockquote>" +
                "<figcaption><strong>" + r.nombre + "</strong><span>" + r.ubicacion + "</span></figcaption>" +
                "</figure>"
            );
        }).join("");
    }


    /* ---------- Detalle de producto ---------- */

    const raiz = document.getElementById("detalle");

    if (!raiz || typeof PRODUCTOS === "undefined") {
        return;
    }

    const soles = new Intl.NumberFormat("es-PE", {
        style: "currency",
        currency: "PEN",
        minimumFractionDigits: 2
    });

    const id = new URLSearchParams(window.location.search).get("id");
    const producto = PRODUCTOS[id];

    /* Producto inexistente: se muestra una salida útil, no una página en blanco. */
    if (!producto) {
        raiz.className = "vacio";
        raiz.innerHTML =
            '<h1>No encontramos esa prenda</h1>' +
            '<p>Puede que el enlace esté incompleto o que la prenda ya no esté disponible.</p>' +
            '<a href="productos.html" class="btn">Ver el catálogo</a>';
        document.title = "Prenda no encontrada | Malakoi";
        return;
    }

    const tallas = tallasProducto(producto);

    /* Textos y metadatos */
    document.title = producto.nombre + " | Malakoi";

    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
        meta.setAttribute("content", producto.descripcion);
    }

    const miga = document.getElementById("miga-actual");
    if (miga) {
        miga.textContent = producto.nombre;
    }

    const imagen = document.getElementById("imagenProducto");
    imagen.src = producto.imagen;
    imagen.alt = producto.nombre + " — Malakoi";

    document.getElementById("nombreProducto").textContent = producto.nombre;

    const precio = document.getElementById("precioProducto");
    precio.innerHTML =
        (producto.precioAnterior
            ? '<span class="precio-anterior">' + soles.format(producto.precioAnterior) + "</span>"
            : "") +
        "<span>" + soles.format(producto.precio) + "</span>";

    document.getElementById("descripcionProducto").textContent = producto.descripcion;

    /* Estado general (agotado / últimas piezas) junto al precio */
    const estadoGeneral = estadoProducto(producto);
    if (estadoGeneral !== "disponible") {
        const badge = document.createElement("span");
        badge.className = "estado-pill estado-" + estadoGeneral;
        badge.textContent = estadoGeneral === "agotado" ? "Agotado" : "Últimas piezas";
        precio.appendChild(badge);
    }

    /* Ficha técnica */
    const ficha = document.getElementById("fichaProducto");
    ficha.innerHTML = Object.entries(producto.ficha)
        .map(function (par) {
            return "<li><strong>" + par[0] + ":</strong> " + par[1] + "</li>";
        })
        .join("");

    /* Nota de tallas (por ejemplo, prendas de talla estándar) */
    const nota = document.getElementById("notaTallas");
    if (nota) {
        if (producto.notaTallas) {
            nota.textContent = producto.notaTallas;
        } else {
            nota.remove();
        }
    }

    /* Selector de tallas */
    const contenedorTallas = document.getElementById("tallas");
    const medidas = document.getElementById("medidas");
    const botonAgregar = document.getElementById("botonAgregarCarrito");

    const enlaceWsp = document.getElementById("whatsapp");
    if (enlaceWsp) {
        const mensaje = "Hola Malakoi, tengo una consulta sobre " + producto.nombre + ". ¿Me ayudan con la talla?";
        enlaceWsp.href = "https://wa.me/" + WHATSAPP + "?text=" + encodeURIComponent(mensaje);
    }

    let tallaActiva = primeraTallaDisponible(producto);

    contenedorTallas.innerHTML = tallas
        .map(function (talla) {
            const agotada = producto.tallas[talla].estado === "agotado";
            return (
                '<button type="button" class="talla' + (agotada ? " talla-agotada" : "") + '" data-talla="' + talla + '" ' +
                'aria-pressed="' + (talla === tallaActiva) + '"' + (agotada ? " disabled" : "") + ">" + talla +
                (agotada ? '<span class="talla-agotada-linea"></span>' : "") +
                "</button>"
            );
        })
        .join("");

    contenedorTallas.addEventListener("click", function (evento) {
        const boton = evento.target.closest(".talla");
        if (!boton || boton.disabled) {
            return;
        }
        tallaActiva = boton.dataset.talla;
        actualizar();
    });

    function actualizar() {

        contenedorTallas.querySelectorAll(".talla").forEach(function (boton) {
            boton.setAttribute("aria-pressed", String(boton.dataset.talla === tallaActiva));
        });

        const infoTalla = producto.tallas[tallaActiva];

        medidas.innerHTML = Object.entries(infoTalla.medidas)
            .map(function (par) {
                return (
                    '<div class="medida"><dt>' + par[0] + "</dt><dd>" + par[1] + "</dd></div>"
                );
            })
            .join("");

        if (botonAgregar) {
            botonAgregar.dataset.talla = tallaActiva;
            if (infoTalla.estado === "agotado") {
                botonAgregar.disabled = true;
                botonAgregar.textContent = "Talla agotada";
            } else {
                botonAgregar.disabled = false;
                botonAgregar.textContent = "Agregar al carrito";
            }
        }

        const avisoStock = document.getElementById("avisoStock");
        if (avisoStock) {
            if (infoTalla.estado === "ultimas") {
                avisoStock.hidden = false;
                avisoStock.textContent = "Últimas " + infoTalla.stock + " unidades en esta talla.";
            } else {
                avisoStock.hidden = true;
            }
        }
    }

    actualizar();

    /* ---------- Cantidad y botón "Agregar al carrito" ---------- */

    if (botonAgregar) {
        botonAgregar.dataset.id = id;
    }

    const inputCantidad = document.getElementById("cantidadProducto");
    const botonMenos = document.getElementById("restarCantidad");
    const botonMas = document.getElementById("sumarCantidad");

    if (botonMenos && inputCantidad) {
        botonMenos.addEventListener("click", function () {
            inputCantidad.value = Math.max(1, Number(inputCantidad.value) - 1);
        });
    }
    if (botonMas && inputCantidad) {
        botonMas.addEventListener("click", function () {
            inputCantidad.value = Math.min(10, Number(inputCantidad.value) + 1);
        });
    }

    /* ---------- Productos relacionados ---------- */

    const seccionRelacionados = document.getElementById("relacionados");
    const grillaRelacionados = document.getElementById("relacionadosGrid");

    if (seccionRelacionados && grillaRelacionados) {

        let relacionados = Object.entries(PRODUCTOS).filter(function (par) {
            return par[0] !== id && par[1].categoria === producto.categoria;
        });

        if (relacionados.length === 0) {
            relacionados = Object.entries(PRODUCTOS).filter(function (par) {
                return par[0] !== id;
            });
        }

        if (relacionados.length === 0) {
            seccionRelacionados.remove();
        } else {
            grillaRelacionados.innerHTML = relacionados
                .map(function (par) {
                    const rid = par[0];
                    const rp = par[1];
                    const rEstado = estadoProducto(rp);
                    const rTalla = primeraTallaDisponible(rp);
                    return (
                        '<article class="producto-card">' +
                        '<div class="producto-card-media">' +
                        '<img src="' + rp.imagen + '" alt="' + rp.nombre + '" width="600" height="800" loading="lazy">' +
                        (rEstado !== "disponible" ? '<span class="etiqueta etiqueta-' + rEstado + '">' + (rEstado === "agotado" ? "Agotado" : "Últimas piezas") + "</span>" : "") +
                        "</div>" +
                        '<div class="producto-card-info">' +
                        '<h3><a href="producto.html?id=' + rid + '">' + rp.nombre + "</a></h3>" +
                        '<p class="precio"><span>' + soles.format(rp.precio) + "</span></p>" +
                        '<button type="button" class="btn-agregar" data-agregar-carrito data-id="' + rid + '" data-talla="' + rTalla + '"' + (rEstado === "agotado" ? " disabled" : "") + ">" + (rEstado === "agotado" ? "Agotado" : "Agregar al carrito") + "</button>" +
                        "</div>" +
                        "</article>"
                    );
                })
                .join("");
        }
    }

    /* Datos estructurados para Google (se arman con el producto ya cargado) */
    const datos = {
        "@context": "https://schema.org",
        "@type": "Product",
        "name": producto.nombre,
        "image": producto.imagen,
        "description": producto.descripcion,
        "brand": { "@type": "Brand", "name": "Malakoi" },
        "offers": {
            "@type": "Offer",
            "priceCurrency": "PEN",
            "price": producto.precio,
            "availability": estadoGeneral === "agotado" ? "https://schema.org/OutOfStock" : "https://schema.org/InStock"
        }
    };

    const script = document.createElement("script");
    script.type = "application/ld+json";
    script.textContent = JSON.stringify(datos);
    document.head.appendChild(script);

})();
